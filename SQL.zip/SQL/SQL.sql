---CREATE DATABSE
CREATE database UPA;


-- Create Department table
CREATE TABLE Department (
  DepartmentID INT PRIMARY KEY,
  DepartmentName VARCHAR(50)
);
SELECT * FROM Department;

-- Create Member table
CREATE TABLE Members (
  MemberID INT PRIMARY KEY,
  FirstName VARCHAR(50),
  LastName VARCHAR(50),
  DepartmentID INT,
  MemberType VARCHAR(50),
  MembershipStatus VARCHAR(50),
  FOREIGN KEY (DepartmentID) REFERENCES Department(DepartmentID)
);
SELECT * FROM Members;


-- Create Author table
CREATE TABLE Authors (
  AuthorID INT PRIMARY KEY,
  AuthorName VARCHAR(50)
);
SELECT * FROM Authors;

-- Create Publisher table
CREATE TABLE Publishers (
  PublisherID INT PRIMARY KEY,
  PublisherName VARCHAR(100)
);
SELECT * FROM Publishers;


-- Create Category table
CREATE TABLE Categories (
  CategoryID INT PRIMARY KEY,
  CategoryName VARCHAR(50),
  Loanable VARCHAR(50), 
  FinePerDay DECIMAL(5,2)
);
SELECT * FROM Categories;


-- Create Books table
CREATE TABLE Books (
  BookID INT PRIMARY KEY,
  ISBN VARCHAR(20),
  Title VARCHAR(100),
  Description TEXT,
  PublisherID INT,
  CategoryID INT,
  PublicationYear INT,
  FOREIGN KEY (PublisherID) REFERENCES Publishers(PublisherID),
  FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID)
);
SELECT * FROM Books;


-- Create BookAuthors table
CREATE TABLE BookAuthors (
  BookID INT,
  AuthorID INT,
  PRIMARY KEY (BookID, AuthorID),
  FOREIGN KEY (BookID) REFERENCES Books(BookID),
  FOREIGN KEY (AuthorID) REFERENCES Authors(AuthorID)
);
SELECT * FROM BookAuthors;

-- Create Reservation table
CREATE TABLE Reservation (
  ReservationID INT PRIMARY KEY,
  MemberID INT,
  BookID INT,
  ReservationDate DATE,
  PickupDate DATE,
  Status VARCHAR(50),
  FOREIGN KEY (MemberID) REFERENCES Members(MemberID),
  FOREIGN KEY (BookID) REFERENCES Books(BookID)
);
SELECT * FROM Reservation;


-- Create Loan table
CREATE TABLE Loans (
  LoanID INT PRIMARY KEY,
  MemberID INT,
  BookID INT,
  LoanDate DATE,
  DueDate DATE,
  ReturnDate DATE,
  FOREIGN KEY (MemberID) REFERENCES Members(MemberID),
  FOREIGN KEY (BookID) REFERENCES Books(BookID)
);
SELECT * FROM Loans;

-- Department
INSERT INTO Department VALUES (1, 'Mathematics');
INSERT INTO Department VALUES (2, 'Physics');
INSERT INTO Department VALUES (3, 'Biology');
INSERT INTO Department VALUES (4, 'Chemistry');
INSERT INTO Department VALUES (5, 'English Literature');
INSERT INTO Department VALUES (6, 'Psychology');
INSERT INTO Department VALUES (7, 'History');
INSERT INTO Department VALUES (8, 'Geography');
INSERT INTO Department VALUES (9, 'Computer Science');
INSERT INTO Department VALUES (10, 'Business');

-- Members 
INSERT INTO Members VALUES (1, 'John', 'Doe', 9, 'Student', 'Active');
INSERT INTO Members VALUES (2, 'Jane', 'Smith', 10, 'Staff', 'Active');
INSERT INTO Members VALUES (3, 'Alice', 'Johnson', 5, 'Student', 'Inactive');
INSERT INTO Members VALUES (4, 'Bob', 'Williams', 1, 'Staff', 'Active');
INSERT INTO Members VALUES (5, 'Charlie', 'Brown', 4, 'Student', 'Inactive');
INSERT INTO Members VALUES (6, 'Eve', 'Davis', 3, 'Staff', 'Active');
INSERT INTO Members VALUES (7, 'David', 'Miller', 2, 'Student', 'Active');
INSERT INTO Members VALUES (8, 'Sophia', 'Wilson', 7, 'Staff', 'Inactive');
INSERT INTO Members VALUES (9, 'Lucas', 'Anderson', 8, 'Student', 'Active');
INSERT INTO Members VALUES (10, 'Emma', 'Thomas', 6, 'Staff', 'Inactive');

-- Authors
INSERT INTO Authors VALUES (1, 'Thomas Connolly');
INSERT INTO Authors VALUES (2, 'Ramez Elmasri');
INSERT INTO Authors VALUES (3, 'C.J. Date');
INSERT INTO Authors VALUES (4, 'Erich Gamma');
INSERT INTO Authors VALUES (5, 'Robert C. Martin');
INSERT INTO Authors VALUES (6, 'Martin Fowler');
INSERT INTO Authors VALUES (7, 'Andrew Hunt');
INSERT INTO Authors VALUES (8, 'Steve McConnell');
INSERT INTO Authors VALUES (9, 'Kent Beck');
INSERT INTO Authors VALUES (10, 'Michael C. Feathers');

-- Publishers
INSERT INTO Publishers VALUES (1, 'Addison-Wesley');
INSERT INTO Publishers VALUES (2, 'Prentice Hall');
INSERT INTO Publishers VALUES (3, 'McGraw-Hill');
INSERT INTO Publishers VALUES (4, 'O�Reilly Media');
INSERT INTO Publishers VALUES (5, 'Packt Publishing');
INSERT INTO Publishers VALUES (6, 'Apress');
INSERT INTO Publishers VALUES (7, 'Manning Publications');
INSERT INTO Publishers VALUES (8, 'Pearson Education');
INSERT INTO Publishers VALUES (9, 'Wiley');
INSERT INTO Publishers VALUES (10, 'Microsoft Press');

-- Categories
INSERT INTO Categories VALUES (1, 'Open-Stack', 'TRUE', 0.5);
INSERT INTO Categories VALUES (2, 'Yellow-Tagged', 'TRUE', 1.0);
INSERT INTO Categories VALUES (3, 'Red-Tagged', 'FALSE', NULL);
INSERT INTO Categories VALUES (4, 'Green-Tagged', 'TRUE', 0.75);
INSERT INTO Categories VALUES (5, 'Reference Books', 'FALSE', NULL);
INSERT INTO Categories VALUES (6, 'Journals', 'FALSE', NULL);
INSERT INTO Categories VALUES (7, 'Student Projects', 'FALSE', NULL);
INSERT INTO Categories VALUES (8, 'Maps', 'FALSE', NULL);
INSERT INTO Categories VALUES (9, 'Textbooks', 'TRUE', 0.5);
INSERT INTO Categories VALUES (10, 'Theses', 'FALSE', NULL);

-- Books 
INSERT INTO Books VALUES (1, '9780321127426', 'Database Systems: The Complete Book', 'Comprehensive database textbook', 2, 1, 2002);
INSERT INTO Books VALUES (2, '9780321396855', 'Clean Code: A Handbook of Agile Software Craftsmanship', 'Principles and best practices of agile programming', 1, 2, 2008);
INSERT INTO Books VALUES (3, '9780201485677', 'Refactoring: Improving the Design of Existing Code', 'Refactoring techniques for software', 3, 3, 1999);
INSERT INTO Books VALUES (4, '9780132350884', 'The Clean Coder: A Code of Conduct for Professional Programmers', 'Practical advice for software professionals', 4, 4, 2011);
INSERT INTO Books VALUES (5, '9780596007126', 'The Pragmatic Programmer: Your Journey to Mastery', 'Guide to pragmatic programming', 5, 5, 1999);
INSERT INTO Books VALUES (6, '9780137081073', 'Implementing Domain-Driven Design', 'Guide to domain-driven design', 6, 6, 2013);
INSERT INTO Books VALUES (7, '9780201633610', 'Design Patterns: Elements of Reusable Object-Oriented Software', 'Guide to design patterns', 7, 7, 1994);
INSERT INTO Books VALUES (8, '9781593275846', 'Eloquent JavaScript: A Modern Introduction to Programming', 'Guide to JavaScript programming', 8, 8, 2015);
INSERT INTO Books VALUES (9, '9780596009205', 'Head First Design Patterns', 'Introduction to design patterns', 9, 9, 2004);
INSERT INTO Books VALUES (10, '9780073523323', 'Operating System Concepts', 'Introduction to operating systems', 10, 10, 2012);

-- BookAuthors 
INSERT INTO BookAuthors VALUES (1, 3);
INSERT INTO BookAuthors VALUES (1, 2);
INSERT INTO BookAuthors VALUES (2, 5);
INSERT INTO BookAuthors VALUES (3, 6);
INSERT INTO BookAuthors VALUES (4, 5);
INSERT INTO BookAuthors VALUES (5, 7);
INSERT INTO BookAuthors VALUES (6, 6);
INSERT INTO BookAuthors VALUES (7, 4);
INSERT INTO BookAuthors VALUES (8, 9);
INSERT INTO BookAuthors VALUES (9, 9);
INSERT INTO BookAuthors VALUES (10, 10);

-- Reservation
INSERT INTO Reservation VALUES (1, 1, 1, '2023-01-01', '2023-01-02', 'On Hold');
INSERT INTO Reservation VALUES (2, 2, 2, '2023-02-01', '2023-02-02', 'On Hold');
INSERT INTO Reservation VALUES (3, 3, 3, '2023-03-01', '2023-03-02', 'On Hold');
INSERT INTO Reservation VALUES (4, 4, 4, '2023-04-01', '2023-04-02', 'On Hold');
INSERT INTO Reservation VALUES (5, 5, 5, '2023-05-01', '2023-05-02', 'On Hold');
INSERT INTO Reservation VALUES (6, 6, 6, '2023-06-01', '2023-06-02', 'On Hold');
INSERT INTO Reservation VALUES (7, 7, 7, '2023-07-01', '2023-07-02', 'On Hold');
INSERT INTO Reservation VALUES (8, 8, 8, '2023-08-01', '2023-08-02', 'On Hold');
INSERT INTO Reservation VALUES (9, 9, 9, '2023-09-01', '2023-09-02', 'On Hold');
INSERT INTO Reservation VALUES (10, 10, 10, '2023-10-01', '2023-10-02', 'On Hold');


-- Loans
INSERT INTO Loans VALUES (11, 1, 2, '2023-01-11', '2023-01-18', NULL);
INSERT INTO Loans VALUES (12, 1, 3, '2023-01-19', '2023-01-26', NULL);
INSERT INTO Loans VALUES (13, 2, 3, '2023-02-11', '2023-02-18', NULL);
INSERT INTO Loans VALUES (14, 2, 4, '2023-02-19', '2023-02-26', NULL);
INSERT INTO Loans VALUES (15, 3, 4, '2023-03-11', '2023-03-18', NULL);
INSERT INTO Loans VALUES (16, 4, 5, '2023-04-11', '2023-04-18', NULL);
INSERT INTO Loans VALUES (17, 4, 6, '2023-04-19', '2023-04-26', NULL);
INSERT INTO Loans VALUES (18, 4, 7, '2023-04-27', '2023-05-04', NULL);
INSERT INTO Loans VALUES (21, 1, 1, '2023-01-11', '2023-01-18', NULL);
INSERT INTO Loans VALUES (20, 5, 8, '2023-05-19', '2023-05-26', NULL);



-----Student 1
--1. List the details of all current book reservations. The list should include member IDs 
-- and names, book IDs and titles as well as the status of each book (i.e. it is �available� 
-- or �loaned out�) reserved.
SELECT M.FirstName, M.LastName, COUNT(*) AS NumOfLoans
FROM Members M
JOIN Loans L ON M.MemberID = L.MemberID
GROUP BY M.MemberID, M.FirstName, M.LastName
HAVING COUNT(*) > 2
ORDER BY M.FirstName, M.LastName;

---2. For each department, list the department names, the total number of books borrowed
-- by its students and the total number of books borrowed by its staff. 
SELECT C.CategoryName, COUNT(*) AS NumOfBooks
FROM Categories C
JOIN Books B ON C.CategoryID = B.CategoryID
GROUP BY C.CategoryID, C.CategoryName
ORDER BY COUNT(*) DESC;


---3. List all details of all members who have borrowed any books written by the author  named �C.J. Date�.
SELECT Members.FirstName, Members.LastName, Department.DepartmentName, Members.MemberType, Members.MembershipStatus
FROM Members 
INNER JOIN 
    Loans ON Members.MemberID = Loans.MemberID 
INNER JOIN 
    BookAuthors ON Loans.BookID = BookAuthors.BookID 
INNER JOIN 
    Authors ON BookAuthors.AuthorID = Authors.AuthorID 
INNER JOIN
    Department ON Members.DepartmentID = Department.DepartmentID
WHERE 
    Authors.AuthorName = 'C.J. Date';
